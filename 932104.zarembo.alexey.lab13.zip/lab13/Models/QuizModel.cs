﻿namespace lab13.Models
{
	public record QuizModel(Quiz quiz);
}
